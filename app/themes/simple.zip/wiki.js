if (window.location.hostname == '2015.igem.org'){
  $('style')[0].disabled=true
}